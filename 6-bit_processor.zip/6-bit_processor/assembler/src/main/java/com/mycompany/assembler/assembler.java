/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.assembler;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class assembler {
     




     public static void main(String[] args) throws IOException {
    	 	 ArrayList<String> content = new ArrayList<>();
         try {

             File filein= new File("AssemblerOutput.txt");
             BufferedReader buffered= new BufferedReader(new FileReader(filein));
             String readLine = "";

             while ((readLine = buffered.readLine()) != null) {
                 
                  content.add(readLine);

             }

         } catch (IOException e) {
         }
         System.out.println("library IEEE;");
         System.out.println("use IEEE.STD_LOGIC_1164.ALL;");
         System.out.println("use IEEE.numeric_std.all;");
         System.out.println("entity Memory is");
         System.out.println("	PORT( Addr : in std_logic_vector( 5 downto 0);");
         System.out.println("			Dout : out std_logic_vector( 5 downto 0);");
         System.out.println("			clock : in std_logic);");
         System.out.println("end Memory;");
         System.out.println("   ");
         System.out.println("architecture Behavioral of Memory is");
         System.out.println("type MemoryType is array ( 63 downto 0) of std_logic_vector(5 downto 0);");
         System.out.println("Signal memorysignal : MemoryType;");
         System.out.println("begin");
         //keywords detection
         String s1 ="";
         String s2=""; 
         String s3 ="";
         int addr = 0;
         OUTER:
         for (int i = 0; i<content.size(); addr++, i++) {
             String[] seg = content.get(i).split(" ");
             switch (seg[0]) {
                 case "LOAD":
                     {
                         s1 = "00";
                 switch (seg[1]) {
                     case "R0,":
                         s2 = "00";
                         break;
                     case "R1,":
                         s2 = "01";
                         break;
                     case "R2,":
                         s2 = "10";
                         break;
                     case "R3,":
                         s2 = "11";
                         break;
                     default:
                         break;
                 }
                         System.out.println("memorysignal(" +addr + ") <= \"" + s1+s2+"00" +"\" ;" );
                         addr = (addr + 1);
                         String value = "000000" + (Integer.toBinaryString(Integer.parseInt(seg[2])));
                         System.out.println("memorysignal(" + addr + ") <= \"" + value.substring(value.length() - 6, value.length() ) +"\" ;" );
                         break;
                     }
                 case "ADD":
                     s1 = "01";
                 switch (seg[1]) {
                     case "R0,":
                         s2 = "00";
                         break;
                     case "R1,":
                         s2 = "01";
                         break;
                     case "R2,":
                         s2 = "10";
                         break;
                     case "R3,":
                         s2 = "11";
                         break;
                     default:
                         break;
                 }
                 switch (seg[2]) {
                     case "R0":
                         s3 = "00";
                         break;
                     case "R1":
                         s3 = "01";
                         break;
                     case "R2":
                         s3 = "10";
                         break;
                     case "R3":
                         s3 = "11";
                         break;
                     default:
                         s3 ="00";
                         break;
                 }
                     System.out.println("memorysignal(" + addr+ ") <= \"" + s1+s2+s3 +"\" ;" );
                     break;


                 case "SUB":
                     s1 = "10";
                 switch (seg[1]) {
                     case "R0,":
                         s2 = "00";
                         break;
                     case "R1,":
                         s2 = "01";
                         break;
                     case "R2,":
                         s2 = "10";
                         break;
                     case "R3,":
                         s2 = "11";
                         break;
                     default:
                         break;
                 }
                 switch (seg[2]) {
                     case "R0":
                         s3 = "00";
                         break;
                     case "R1":
                         s3 = "01";
                         break;
                     case "R2":
                         s3 = "10";
                         break;
                     case "R3":
                         s3 = "11";
                         break;
                     default:
                         s3 ="00";
                         break;
                 }
                     System.out.println("memorysignal(" + addr + ") <= \"" + s1+s2+s3 +"\" ;" );
                     break;


                 case "JNZ":
                     {
                         s1 = "11";
                 switch (seg[1]) {
                     case "R0,":
                         s2 = "00";
                         break;
                     case "R1,":
                         s2 = "01";
                         break;
                     case "R2,":
                         s2 = "10";
                         break;
                     case "R3,":
                         s2 = "11";
                         break;
                     default:
                         break;
                 }
                         System.out.println("memorysignal(" +addr+ ") <= \"" + s1+s2+"00" +"\" ;" );
                         addr = (addr + 1);
                         String value = "000000" + (Integer.toBinaryString(Integer.parseInt(seg[2])));
                         System.out.println("memorysignal(" + addr+ ") <= \"" + value.substring(value.length() - 6, value.length() ) +"\" ;" );
                         break;
                     }
                 case "HLT":
                     System.out.println("memorysignal(" + addr + ") <= \"" + "111111" +"\" ;" );
                     break OUTER;
                 default:
                     break;
             }
         }
         System.out.println();
         System.out.println("Dout <= memorysignal( to_integer(unsigned(Addr)));");
         System.out.println("end Behavioral;");
             }

 }

